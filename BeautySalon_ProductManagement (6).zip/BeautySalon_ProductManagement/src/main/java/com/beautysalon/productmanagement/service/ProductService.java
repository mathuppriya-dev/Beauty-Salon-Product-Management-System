package com.beautysalon.productmanagement.service;

import com.beautysalon.productmanagement.model.HairProduct;
import com.beautysalon.productmanagement.model.Product;
import com.beautysalon.productmanagement.model.SkinProduct;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.springframework.stereotype.Service;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;

@Service
public class ProductService {


    private final String productFile = "data/products.json";

    private final Stack<Product> recentlyViewed = new Stack<>();
    private final Queue<Product> outOfStockQueue = new LinkedList<>();

    public List<Product> getAllProducts() {
        File file = new File(productFile);
        try {
            // ✅ Create data/products.json if it doesn't exist
            if (!file.exists()) {
                file.getParentFile().mkdirs(); // Create "data" directory if missing
                file.createNewFile(); // Create products.json file
                try (FileWriter writer = new FileWriter(file)) {
                    writer.write("[]"); // Start with empty JSON array
                }
            }

            // ✅ Now safely read the file
            try (Reader reader = new FileReader(file)) {
                Gson gson = new Gson();
                Type productListType = new TypeToken<List<Product>>() {}.getType();
                List<Product> products = gson.fromJson(reader, productListType);
                return products != null ? products : new ArrayList<>();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }


    public void saveAllProducts(List<Product> products) {
        try (Writer writer = new FileWriter(productFile)) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(products, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addProduct(Product product) {
        String id = UUID.randomUUID().toString();
        Product newProduct;

        if ("Hair".equalsIgnoreCase(product.getCategory())) {
            newProduct = new HairProduct(id, product.getName(), product.getPrice(), product.getStock(), product.getImageUrl(), product.getDescription());
        } else if ("Skin".equalsIgnoreCase(product.getCategory())) {
            newProduct = new SkinProduct(id, product.getName(), product.getPrice(), product.getStock(), product.getImageUrl(), product.getDescription());
        } else {
            newProduct = new Product(id, product.getName(), product.getCategory(), product.getPrice(), product.getStock(), product.getImageUrl(), product.getDescription());
        }

        List<Product> products = getAllProducts();
        products.add(newProduct);
        saveAllProducts(products);
    }

    public boolean updateProduct(String id, Product updatedProduct) {
        List<Product> products = getAllProducts();
        for (Product product : products) {
            if (product.getId().equals(id)) {
                product.setName(updatedProduct.getName());
                product.setCategory(updatedProduct.getCategory());
                product.setPrice(updatedProduct.getPrice());
                product.setStock(updatedProduct.getStock());
                product.setImageUrl(updatedProduct.getImageUrl());
                product.setDescription(updatedProduct.getDescription());
                saveAllProducts(products);
                return true;
            }
        }
        return false;
    }

    public boolean deleteProduct(String id) {
        List<Product> products = getAllProducts();
        boolean removed = products.removeIf(p -> p.getId().equals(id));
        if (removed) {
            saveAllProducts(products);
        }
        return removed;
    }

    public Product getProductById(String id) {
        return getAllProducts().stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
    }


    // Recently Viewed
    public void addRecentlyViewed(Product product) {
        recentlyViewed.push(product);
        if (recentlyViewed.size() > 5) {
            recentlyViewed.remove(0);
        }
    }

    public List<Product> getRecentlyViewed() {
        List<Product> reversed = new ArrayList<>(recentlyViewed);
        Collections.reverse(reversed);
        return reversed;
    }

    // Out-of-Stock
    public void checkStockAndQueue(Product product) {
        if (product.getStock() <= 0 && !outOfStockQueue.contains(product)) {
            outOfStockQueue.add(product);
        }
    }

    public List<Product> getOutOfStockQueue() {
        List<Product> outOfStock = new ArrayList<>();
        for (Product product : getAllProducts()) {
            if (product.getStock() == 0) {
                outOfStock.add(product);
            }
        }
        return outOfStock;
    }

    // Merge Sort
    public List<Product> getSortedProducts(String sortBy) {
        List<Product> copy = new ArrayList<>(getAllProducts());
        mergeSort(copy, sortBy);
        return copy;
    }

    private void mergeSort(List<Product> list, String sortBy) {
        if (list.size() <= 1) return;
        int mid = list.size() / 2;
        List<Product> left = new ArrayList<>(list.subList(0, mid));
        List<Product> right = new ArrayList<>(list.subList(mid, list.size()));

        mergeSort(left, sortBy);
        mergeSort(right, sortBy);
        merge(list, left, right, sortBy);
    }
    private void merge(List<Product> result, List<Product> left, List<Product> right, String sortBy) {
        result.clear();
        int i = 0, j = 0;
        while (i < left.size() && j < right.size()) {
            Product p1 = left.get(i);
            Product p2 = right.get(j);
            int compare = 0;

            switch (sortBy.toLowerCase()) {
                case "name":
                    compare = p1.getName().compareToIgnoreCase(p2.getName());
                    break;
                case "price":
                    compare = Double.compare(p1.getPrice(), p2.getPrice());
                    break;
                case "stock":
                    compare = Integer.compare(p1.getStock(), p2.getStock());
                    break;
                default:
                    compare = p1.getId().compareToIgnoreCase(p2.getId());
            }

            if (compare <= 0) {
                result.add(p1);
                i++;
            } else {
                result.add(p2);
                j++;
            }
        }

        while (i < left.size()) result.add(left.get(i++));
        while (j < right.size()) result.add(right.get(j++));
    }

}





