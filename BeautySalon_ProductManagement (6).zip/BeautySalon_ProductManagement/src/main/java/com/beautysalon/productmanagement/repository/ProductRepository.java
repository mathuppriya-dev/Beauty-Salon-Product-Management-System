package com.beautysalon.productmanagement.repository;

import com.beautysalon.productmanagement.model.Product;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ProductRepository {
    private final String filePath = "data/products.json";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();



    public List<Product> getAllProducts() {
        try {
            if (!Files.exists(Paths.get(filePath))) {
                return new ArrayList<>();
            }
            Reader reader = new FileReader(filePath);
            Type productListType = new TypeToken<List<Product>>() {}.getType();
            List<Product> products = gson.fromJson(reader, productListType);
            reader.close();
            return products != null ? products : new ArrayList<>();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    public void saveAllProducts(List<Product> products) {
        try (FileWriter writer = new FileWriter(filePath)) {
            gson.toJson(products, writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addProduct(Product product) {
        List<Product> products = getAllProducts();
        // Optional: check for duplicate ID
        if (products.stream().anyMatch(p -> p.getId().equals(product.getId()))) {
            return false; // product with this ID already exists
        }
        products.add(product);
        saveAllProducts(products);
        return true;
    }

    public Product getProductById(String id) {
        return getAllProducts().stream()
                .filter(p -> p.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public boolean updateProduct(Product updatedProduct) {
        List<Product> products = getAllProducts();
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId().equals(updatedProduct.getId())) {
                products.set(i, updatedProduct);
                saveAllProducts(products);
                return true;
            }
        }
        return false;
    }

    public boolean deleteProduct(String id) {
        List<Product> products = getAllProducts();
        boolean removed = products.removeIf(p -> p.getId().equals(id));
        if (removed) {
            saveAllProducts(products);
        }
        return removed;
    }
}


