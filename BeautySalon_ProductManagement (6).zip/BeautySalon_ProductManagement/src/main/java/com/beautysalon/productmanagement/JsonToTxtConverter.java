package com.beautysalon.productmanagement; // 👈 Make sure this matches your package name

import com.beautysalon.productmanagement.model.Product;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

public class JsonToTxtConverter {

    public static void main(String[] args) {
        try {
            // Step 1: Read from products.json
            Gson gson = new Gson();
            Reader reader = new FileReader("data/products.json");

            Type productListType = new TypeToken<List<Product>>() {}.getType();
            List<Product> products = gson.fromJson(reader, productListType);

            // Step 2: Write to products.txt
            BufferedWriter writer = new BufferedWriter(new FileWriter("data/products.txt"));
            for (Product product : products) {
                String line = product.getId() + "," + product.getName() + "," +
                        product.getPrice() + "," + product.getStock();
                writer.write(line);
                writer.newLine();
            }
            writer.close();
            reader.close();

            System.out.println("✅ Converted products.json to products.txt");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

