package com.beautysalon.productmanagement.controller;

import com.beautysalon.productmanagement.model.Product;
import com.beautysalon.productmanagement.service.ProductService;
import com.beautysalon.productmanagement.service.ProductStackQueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductStackQueueService stackQueueService;

    /**
     * Get all products.
     */
    @GetMapping
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    /**
     * Add a new product.
     */
    @PostMapping
    public ResponseEntity<String> addProduct(@RequestBody Product product) {
        productService.addProduct(product);
        return ResponseEntity.status(HttpStatus.CREATED).body("Product added successfully.");
    }

    /**
     * Update a product by ID.
     */
    @PutMapping("/{id}")
    public ResponseEntity<String> updateProduct(@PathVariable String id, @RequestBody Product updatedProduct) {
        boolean success = productService.updateProduct(id, updatedProduct);
        if (success) {
            return ResponseEntity.ok("Product updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found.");
        }
    }

    /**
     * Delete a product by ID.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable String id) {
        boolean deleted = productService.deleteProduct(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Get a product by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable String id) {
        Product product = productService.getProductById(id);
        if (product != null) {
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Get the total product count.
     */
    @GetMapping("/count")
    public int getProductCount() {
        return productService.getAllProducts().size();
    }

    /**
     * Push a product to the viewed stack.
     */
    @PostMapping("/viewed")
    public ResponseEntity<Void> pushViewedProduct(@RequestBody Product product) {
        stackQueueService.pushViewedProduct(product);
        return ResponseEntity.ok().build();
    }

    /**
     * Get the viewed products stack.
     */
    @GetMapping("/viewed")
    public ResponseEntity<List<Product>> getViewedProducts() {
        return ResponseEntity.ok(stackQueueService.getRecentlyViewedProducts());
    }

    /**
     * Enqueue a product into the restock queue.
     */
    @PostMapping("/restock")
    public ResponseEntity<Void> enqueueRestock(@RequestBody Product product) {
        stackQueueService.enqueueRestock(product);
        return ResponseEntity.ok().build();
    }

    /**
     * Get all products in the restock queue.
     */
    @GetMapping("/restock")
    public ResponseEntity<List<Product>> getRestockQueue() {
        return ResponseEntity.ok(stackQueueService.getRestockQueue());
    }

    /**
     * Dequeue (restock) one product from the restock queue.
     */
    @DeleteMapping("/restock")
    public ResponseEntity<Product> dequeueRestock() {
        Product product = stackQueueService.dequeueRestock();
        if (product != null) {
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.noContent().build();
        }
    }

    /**
     * Get the recently viewed product list.
     */
    @GetMapping("/recently-viewed")
    public ResponseEntity<List<Product>> getRecentlyViewed() {
        return ResponseEntity.ok(productService.getRecentlyViewed());
    }

    /**
     * Get the out-of-stock product queue.
     */
    @GetMapping("/out-of-stock")
    public ResponseEntity<List<Product>> getOutOfStock() {
        return ResponseEntity.ok(productService.getOutOfStockQueue());
    }

    /**
     * View a product (simulate view by ID): push to viewed stack and enqueue to restock.
     */
    @GetMapping("/view/{id}")
    public ResponseEntity<Product> viewProduct(@PathVariable String id) {
        Product product = productService.getProductById(id);
        if (product != null) {
            stackQueueService.pushViewedProduct(product);
            stackQueueService.enqueueRestock(product);
            productService.addRecentlyViewed(product);
            return ResponseEntity.ok(product);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
