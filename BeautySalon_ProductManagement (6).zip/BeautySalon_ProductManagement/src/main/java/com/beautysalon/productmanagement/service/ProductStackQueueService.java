package com.beautysalon.productmanagement.service;

import com.beautysalon.productmanagement.model.Product;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ProductStackQueueService {

    // Stack for recently viewed products
    private Stack<Product> recentViewedStack = new Stack<>();

    // Queue for products to be restocked
    private Queue<Product> restockQueue = new LinkedList<>();

    // Add to stack
    public void pushViewedProduct(Product product) {
        if (product != null) {
            recentViewedStack.push(product);
            if (recentViewedStack.size() > 5) {
                recentViewedStack.remove(0); // remove the oldest one
            }
        }
    }


    public List<Product> getRecentlyViewedProducts() {
        return new ArrayList<>(recentViewedStack);
    }

    // Add to restock queue
    public void enqueueRestock(Product product) {
        if (product != null && product.getStock() <= 0) {
            restockQueue.add(product);
        }
    }

    public Product dequeueRestock() {
        return restockQueue.poll(); // remove and return
    }

    public List<Product> getRestockQueue() {
        return new ArrayList<>(restockQueue);
    }
}
