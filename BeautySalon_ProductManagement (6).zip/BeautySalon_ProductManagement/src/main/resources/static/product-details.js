const productId = new URLSearchParams(window.location.search).get("id");
const productName = document.getElementById("product-name");
const productImage = document.getElementById("product-image");
const productDescription = document.getElementById("product-description");
const productPrice = document.getElementById("product-price");
const productStock = document.getElementById("product-stock");
const productCategory = document.getElementById("product-category");
const addToCartBtn = document.getElementById("add-to-cart-btn");

if (!productId) {
    Swal.fire("Error", "Product ID not found", "error").then(() => {
        window.location.href = "product-list.html";
    });
}

async function fetchProduct(id) {
    try {
        const response = await fetch(`/products/${id}`);
        if (!response.ok) throw new Error("Product not found");
        const product = await response.json();

        productName.textContent = product.name || "N/A";
        productImage.src = (product.imageUrl && product.imageUrl.trim() !== "")
            ? product.imageUrl
            : "https://via.placeholder.com/600x400?text=No+Image"; // ✅ Only change
        productDescription.textContent = product.description || "No description available";
        productPrice.textContent = `$${product.price?.toFixed(2) || "0.00"}`;
        productStock.textContent = product.stock ?? "0";
        productCategory.textContent = product.category || "Uncategorized";

        // Add to recently viewed
        fetch(`/products/recently-viewed/add/${id}`, { method: "POST" });

    } catch (error) {
        Swal.fire("Error", error.message, "error").then(() => {
            window.location.href = "product-list.html";
        });
    }
}

addToCartBtn.addEventListener("click", () => {
    Swal.fire("Added to Cart", "The product has been added to your cart.", "success");
    // TODO: Implement cart storage or backend call here
});

fetchProduct(productId);



/* Original snippet preserved:
productImage.src = product.image || "placeholder.png"; // old code
*/
