const form = document.querySelector("form");
const nameInput = document.getElementById("name");
const descriptionInput = document.getElementById("description");
const priceInput = document.getElementById("price");
const stockInput = document.getElementById("stock");
const categoryInput = document.getElementById("category");
const imageUrlInput = document.getElementById("imageUrl");

const urlParams = new URLSearchParams(window.location.search);
const productId = urlParams.get("id");

const BASE_URL = "http://localhost:8080";

if (!productId) {
    Swal.fire("Error", "No product ID provided", "error").then(() => {
        window.location.href = "product-list.html";
    });
}

async function fetchProductDetails(id) {
    try {
        const response = await fetch(`${BASE_URL}/products/${id}`);
        if (!response.ok) throw new Error("Product not found");
        const product = await response.json();

        nameInput.value = product.name || "";
        descriptionInput.value = product.description || "";
        priceInput.value = product.price || 0;
        stockInput.value = product.stock || 0;
        categoryInput.value = product.category || "";
        imageUrlInput.value = product.imageUrl || "";
    } catch (error) {
        Swal.fire("Error", error.message, "error").then(() => {
            window.location.href = "product-list.html";
        });
    }
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    form.querySelector("button[type='submit']").disabled = true;

    const updatedProduct = {
        name: nameInput.value,
        description: descriptionInput.value,
        price: parseFloat(priceInput.value),
        stock: parseInt(stockInput.value, 10),
        category: categoryInput.value,
        imageUrl: imageUrlInput.value,
    };

    const result = await Swal.fire({
        title: "Confirm Update",
        text: "Are you sure you want to update this product?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, update it!",
    });

    if (result.isConfirmed) {
        try {
            const response = await fetch(`${BASE_URL}/products/${productId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updatedProduct),
            });

            if (!response.ok) throw new Error("Failed to update product");

            await Swal.fire("Success", "Product updated successfully!", "success");
            window.location.href = "product-list.html";
        } catch (error) {
            await Swal.fire("Error", error.message, "error");
            form.querySelector("button[type='submit']").disabled = false;
        }
    } else {
        form.querySelector("button[type='submit']").disabled = false;
    }
});

fetchProductDetails(productId);



