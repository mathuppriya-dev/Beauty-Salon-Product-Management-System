const productList = document.getElementById("product-list");
const searchInput = document.getElementById("search");
const mobileMenuToggle = document.getElementById("mobile-menu-toggle");
const mobileMenu = document.querySelector(".mobile-menu");

let products = [];

function renderProducts(filteredProducts) {
    productList.innerHTML = "";
    if (filteredProducts.length === 0) {
        productList.innerHTML = `<p>No products found.</p>`;
        return;
    }
    filteredProducts.forEach((product) => {
        const productCard = document.createElement("div");
        productCard.classList.add("product-card");
        productCard.dataset.productId = product.id;

        productCard.innerHTML = `
      <img src="${product.imageUrl || "placeholder.png"}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <p>Price: $${product.price?.toFixed(2) || "0.00"}</p>
      <p>Stock: ${product.stock ?? "0"}</p>
      <div class="actions">
        <button class="view-btn" data-id="${product.id}">View</button>
        <button class="edit-btn" data-id="${product.id}">Edit</button>
        <button class="delete-btn" data-id="${product.id}">Delete</button>
      </div>
    `;

        productList.appendChild(productCard);
    });
}

// Debounce helper function
function debounce(fn, delay) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn.apply(this, args), delay);
    };
}

function filterProducts() {
    const query = searchInput.value.toLowerCase().trim();
    if (!query) {
        renderProducts(products);
        return;
    }
    const filtered = products.filter(
        (p) =>
            p.name.toLowerCase().includes(query) || String(p.id).includes(query)
    );
    renderProducts(filtered);
}

async function fetchProducts() {
    try {
        const response = await fetch("/products");
        if (!response.ok) throw new Error("Failed to fetch products");
        products = await response.json();
        renderProducts(products);
    } catch (error) {
        productList.innerHTML = `<p>Error loading products: ${error.message}</p>`;
    }
}

productList.addEventListener("click", async (event) => {
    const target = event.target;
    const id = target.dataset.id;

    if (!id) return;

    if (target.classList.contains("view-btn")) {
        window.location.href = `product-details.html?id=${id}`;
    }

    if (target.classList.contains("edit-btn")) {
        window.location.href = `edit-product.html?id=${id}`;
    }

    if (target.classList.contains("delete-btn")) {
        const result = await Swal.fire({
            title: "Confirm Delete",
            text: "Are you sure you want to delete this product?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Delete",
        });

        if (result.isConfirmed) {
            try {
                // Optimistically remove from DOM
                const card = target.closest(".product-card");
                if (card) card.remove();

                const response = await fetch(`/products/${id}`, {
                    method: "DELETE",
                });

                if (!response.ok) throw new Error("Delete failed");
                Swal.fire("Deleted!", "Product has been deleted.", "success");

                // Refresh product list in case of changes
                await fetchProducts();

            } catch (error) {
                Swal.fire("Error", error.message, "error");
                // Re-fetch products to reset UI in case of error
                await fetchProducts();
            }
        }
    }
});

// Toggle mobile menu
mobileMenuToggle.addEventListener("click", () => {
    mobileMenu.classList.toggle("active");
});

searchInput.addEventListener("input", debounce(filterProducts, 300));

fetchProducts();

/* Original code preserved for search handler:
searchInput.addEventListener("input", filterProducts);
*/
